files_by_section = {
    "GIT ": {
        "GIT 1": "https://docs.google.com/presentation/d/1d6byImqhhAzkHykwvuNvCMYJmwhOUP43/export/pdf"
    },
    "Epidemiology": {
        "Epidemiology 1": "https://docs.google.com/presentation/d/1dIHqkqKf1lD47k1dHFzh1xWpyMby0PFz/export/pdf",
        "Epidemiology 2": "https://docs.google.com/presentation/d/1dBWcNt2rqpTCzv61Ri2XoLP-CkGChdDA/export/pdf"
    }
}